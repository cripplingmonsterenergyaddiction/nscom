import org.apache.commons.net.tftp.TFTPClient;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the server IP address: ");
        String serverIp = scanner.nextLine();
        System.out.println("Enter the operation (upload/download): ");
        String operation = scanner.nextLine().toLowerCase();

        // Use the specific file path instead of prompting the user for a filename
        String filename = "C:\\Program Files\\Tftpd64";

        if (operation.equals("upload")) {
            File file = new File(filename);
            if (file.exists() && file.canRead()) {
                uploadFile(serverIp, filename);
            } else {
                System.out.println("File not found or access violation.");
            }
        } else if (operation.equals("download")) {
            System.out.println("Enter the local filename to save as: ");
            String localFilename = scanner.nextLine();
            File file = new File(localFilename);
            if (file.getAbsoluteFile().getParentFile().canWrite()) {
                downloadFile(serverIp, filename, localFilename);
            } else {
                System.out.println("Disk full or access violation.");
            }
        } else {
            System.out.println("Invalid operation.");
        }
    }

    public static void uploadFile(String serverIp, String filename) {
        TFTPClient tftpClient = new TFTPClient();
        FileInputStream fileInputStream = null;

        try {
            tftpClient.open();
            fileInputStream = new FileInputStream(filename);
            tftpClient.sendFile(filename, TFTPClient.BINARY_MODE, fileInputStream, serverIp);
            System.out.println("File " + filename + " uploaded successfully.");
        } catch (IOException e) {
            System.out.println("Error occurred while uploading: " + e.getMessage());
        } finally {
            try {
                if (fileInputStream != null) {
                    fileInputStream.close();
                }
                tftpClient.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static void downloadFile(String serverIp, String filename, String localFilename) {
        TFTPClient tftpClient = new TFTPClient();
        FileOutputStream fileOutputStream = null;

        try {
            tftpClient.open();
            fileOutputStream = new FileOutputStream(localFilename);
            tftpClient.receiveFile(filename, TFTPClient.BINARY_MODE, fileOutputStream, serverIp);
            System.out.println("File " + filename + " downloaded successfully as " + localFilename + ".");
        } catch (IOException e) {
            System.out.println("Error occurred while downloading: " + e.getMessage());
        } finally {
            try {
                if (fileOutputStream != null) {
                    fileOutputStream.close();
                }
                tftpClient.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
