import java.io.*;
import java.net.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws Exception {
        tftpClient tftpClient = new tftpClient();
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the server IP address: ");
        String serverIp = scanner.nextLine();
        System.out.println("Enter the operation (upload/download): ");
        String operation = scanner.nextLine().toLowerCase();

        if (operation.equals("upload")) {
            // Prompt the user for the file path and file name
            System.out.println("Enter the file path: ");
            String filePath = scanner.nextLine();
            System.out.println("Enter the file name: ");
            String fileName = scanner.nextLine();

            File file = new File(filePath, fileName);
            if (file.exists() && file.canRead()) {
                try {
                    tftpClient.executeTFTPUpload(serverIp, filePath, fileName);
                } catch (Exception e) {
                    System.out.println("Error occurred while uploading: " + e.getMessage());
                }
            } else {
                System.out.println("File not found or access violation.");
            }
        } else if (operation.equals("download")) {
            System.out.println("Enter the local filename to save as: ");
            String localFilename = scanner.nextLine();
            System.out.println("Enter the filename to download: ");
            String fileName = scanner.nextLine();
            File file = new File(localFilename);
            if (file.getAbsoluteFile().getParentFile().canWrite()) {
                try {
                    tftpClient.downloadFile(serverIp, fileName, localFilename);
                } catch (Exception e) {
                    System.out.println("Error occurred while downloading: " + e.getMessage());
                }
            } else {
                System.out.println("Disk full or access violation.");
            }
        } else {
            System.out.println("Invalid operation.");
        }
    }
}