import java.io.*;
import java.net.*;
import org.apache.commons.net.tftp.TFTPClient;
import org.apache.commons.net.tftp.TFTPClient;

public class tftpClient {

    private static final int DEFAULT_PORT = 69;
    private static final int BLOCK_SIZE = 512;

    public void executeTFTPUpload(String serverAddress, String filePath, String fileName) throws Exception {
        // Check if file exists
        File file = new File(filePath, fileName);
        if (!file.exists()) {
            System.err.println("Error: File not found: " + file.getAbsolutePath());
            return;
        }

        // Send WRQ packet using DatagramSocket
        DatagramSocket socket = new DatagramSocket();
        socket.setSoTimeout(3000); // 3 seconds timeout

        byte[] wrqPacket = createWRQPacket(fileName);
        DatagramPacket wrqDatagram = new DatagramPacket(wrqPacket, wrqPacket.length, InetAddress.getByName(serverAddress), DEFAULT_PORT);
        socket.send(wrqDatagram);

        // Receive initial ACK
        byte[] buffer = new byte[BLOCK_SIZE];
        DatagramPacket ackDatagram = new DatagramPacket(buffer, buffer.length);
        socket.receive(ackDatagram);

        if (buffer[1] != 4 || (buffer[2] << 8 | buffer[3]) != 0) {
            System.err.println("Error: Unexpected response from server");
            return;
        }

        // Send data packets
        int blockNumber = 1;
        int serverDataPort = ackDatagram.getPort();
        try (FileInputStream fileInputStream = new FileInputStream(file)) {
            while (true) {
                int bytesRead = fileInputStream.read(buffer, 4, BLOCK_SIZE - 4);
                if (bytesRead == -1) {
                    break;
                }

                buffer[0] = 0;
                buffer[1] = 3;
                buffer[2] = (byte) ((blockNumber >> 8) & 0xFF);
                buffer[3] = (byte) (blockNumber & 0xFF);

                DatagramPacket dataDatagram = new DatagramPacket(buffer, bytesRead + 4, InetAddress.getByName(serverAddress), serverDataPort);
                socket.send(dataDatagram);

                // Receive ACK
                ackDatagram = new DatagramPacket(buffer, buffer.length);
                socket.receive(ackDatagram);

                if (buffer[1] != 4 || (buffer[2] << 8 | buffer[3]) != blockNumber) {
                    System.err.println("Error: Unexpected response from server (ACK)");
                    continue;
                }

                blockNumber++;
            }
        }

        // Close connection
        socket.close();
        System.out.println("File uploaded successfully!");
    }

    private byte[] createRRQPacket(String filename) throws IOException {
        try (ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
            baos.write(new byte[] {0, 1}); // Opcode: Read Request (RRQ)
            baos.write(filename.getBytes());
            baos.write(0); // Null terminator
            baos.write("octet".getBytes()); // Transfer mode (octet)
            baos.write(0); // Null terminator
            return baos.toByteArray();
        }
    }
    
    public void downloadFile(String serverIp, String filename, String localFilename) throws IOException {
        try (DatagramSocket socket = new DatagramSocket()) {
            socket.setSoTimeout(3000); // 3 seconds timeout
    
            // Send RRQ packet using DatagramSocket
            byte[] rrqPacket = createRRQPacket(filename);
            DatagramPacket rrqDatagram = new DatagramPacket(rrqPacket, rrqPacket.length, InetAddress.getByName(serverIp), DEFAULT_PORT);
            socket.send(rrqDatagram);
    
            // Receive initial data packet
            byte[] buffer = new byte[BLOCK_SIZE];
            DatagramPacket dataDatagram = new DatagramPacket(buffer, buffer.length);
            socket.receive(dataDatagram);
    
            // Check for error response
            if (buffer[1] != 3) {
                System.err.println("Error: Unexpected response from server");
                return;
            }
    
            // Process data packets and write to file
            int blockNumber = 1;
            int serverDataPort = dataDatagram.getPort();
            try (FileOutputStream fileOutputStream = new FileOutputStream(localFilename)) {
                while (true) {
                    // Write received data to file
                    fileOutputStream.write(buffer, 4, dataDatagram.getLength() - 4); // Skip first 4 bytes (opcode, block number)
    
                    // Send ACK packet
                    buffer[0] = 0;
                    buffer[1] = 4;
                    buffer[2] = (byte) ((blockNumber >> 8) & 0xFF);
                    buffer[3] = (byte) (blockNumber & 0xFF);
    
                    DatagramPacket ackDatagram = new DatagramPacket(buffer, 4, InetAddress.getByName(serverIp), serverDataPort);
                    socket.send(ackDatagram);
    
                    // Receive next data packet
                    dataDatagram = new DatagramPacket(buffer, buffer.length);
                    socket.receive(dataDatagram);
    
                    // Check for end of file or error
                    if (dataDatagram.getLength() < 4) { // Empty packet indicates end of file
                        break;
                    } else if (buffer[1] != 3) {
                        System.err.println("Error: Unexpected response from server (data)");
                        break;
                    }
    
                    blockNumber++;
                }
            }
    
            System.out.println("File " + filename + " downloaded successfully as " + localFilename + ".");
        } catch (IOException e) {
            System.out.println("Error occurred while downloading: " + e.getMessage());
        }
    }
    

 

    private static byte[] createWRQPacket(String fileName) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try {
            baos.write(new byte[] {0, 2}); // Opcode: Write Request (WRQ)
            baos.write(fileName.getBytes());
            baos.write(0); // Null terminator
            baos.write("octet".getBytes());
            baos.write(0); // Null terminator
        } catch (IOException e) {
            e.printStackTrace();
        }
        return baos.toByteArray();
    }
}
